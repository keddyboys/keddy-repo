import HTMLParser
import os
import re
import sys
import urllib
import urllib2
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

settings = xbmcaddon.Addon(id='plugin.video.triluliluro')

search_thumb = os.path.join(settings.getAddonInfo('path'), 'resources', 'media', 'search.png')
movies_thumb = os.path.join(settings.getAddonInfo('path'), 'resources', 'media', 'movies.png')
next_thumb = os.path.join(settings.getAddonInfo('path'), 'resources', 'media', 'next.png')


def ROOT():
    addDir('Haioase', 'http://www.trilulilu.ro/', 1, movies_thumb)
    addDir('Fail', 'http://www.trilulilu.ro/', 6, movies_thumb)
    addDir('Wow', 'http://www.trilulilu.ro/', 7, movies_thumb)
    addDir('Reclame', 'http://www.trilulilu.ro/', 8, movies_thumb)
    addDir('Cauta', 'http://www.trilulilu.ro/', 3, search_thumb)
    addDir('Cauta ... dublat', 'http://www.trilulilu.ro/', 31, search_thumb)
    

def CAUTA_LIST(url):
    link = get_search(url)
                   
    match = re.compile('<a href="(http://www.trilulilu.ro/video-.+?)#ref=cauta" .+?title="(.+?)" .+?>\n.+?<div.+?>(\d+:\d+)</div><img (src|data-src)="(.+?)" width="', re.IGNORECASE | re.MULTILINE).findall(link)
    if len(match) > 0:
        print match
        for legatura, name, length, s, img in match:
            #name = HTMLParser.HTMLParser().unescape(  codecs.decode(name, "unicode_escape") ) + " " + length
            name = name + " " + length
            the_link = legatura
            image = img
            sxaddLink(name, the_link, image, name, 10)

    match = re.compile('<link rel="next" href="\?offset=(\d+)" />', re.IGNORECASE).findall(link)
    if len(match) > 0:
        nexturl = re.sub('\?offset=(\d+)', '?offset=' + match[0], url)
        if nexturl.find("offset=") == -1:
            nexturl += '?offset=' + match[0]
      
        print "NEXT " + nexturl
      
        addNext('Next', nexturl, 2, next_thumb)
            
 
def CAUTA_VIDEO_LIST(url):
    link = get_search(url)
    match = re.compile('<a href="(http://www.trilulilu.ro/.+?)#ref=browse" .+?title="(.+?)" .+?>\n.+?<div.+?>(\d+:\d+)</div><img (src|data-src)="(.+?)" width="', re.IGNORECASE | re.MULTILINE).findall(link)
    #f = open( '/storage/.kodi/temp/files.py', 'w' )
    #f.write( 'match = ' + repr(match) + '\n' )
    #f.close()
    if len(match) > 0:
        print match
        for legatura, name, length, s, img in match:
            #name = HTMLParser.HTMLParser().unescape(  codecs.decode(name, "unicode_escape") ) + " " + length
            name = name + " " + length
            the_link = legatura
            image = img
            sxaddLink(name, the_link, image, name, 10)

    match = re.compile('<link rel="next" href=".+?offset=(\d+)" />', re.IGNORECASE).findall(link)
    if len(match) > 0:
        nexturl = re.sub('offset=(\d+)', 'offset=' + match[0], url)
        if nexturl.find("offset=") == -1:
            nexturl += '&offset=' + match[0]
        print "NEXT " + nexturl
        #f = open( '/storage/.kodi/temp/files.py', 'w' )
        #f.write( 'match = ' + repr(nexturl) + '\n' )
        #f.close()
        addNext('Next', nexturl, 5, next_thumb)
            

def CAUTA(url, autoSearch=None):
    keyboard = xbmc.Keyboard('')
    keyboard.doModal()
    if (keyboard.isConfirmed() == False):
        return
    search_string = keyboard.getText()
    if len(search_string) == 0:
        return
        
    if autoSearch is None:
        autoSearch = ""
    
    CAUTA_LIST(get_search_url(search_string + "" + autoSearch))

def CAUTA_VIDEO(url, gen, autoSearch=None):
    
    CAUTA_VIDEO_LIST(get_search_video_url(gen))
    
def SXVIDEO_GENERIC_PLAY(sxurl):
    import YDStreamExtractor
    #url = "http://www.youtube.com/watch?v=_yVv9dx88x0"   #a youtube ID will work as well and of course you could pass the url of another site
    url = sxurl
    src = get_url(urllib.quote(url, safe="%/:=&?~#+!$,;'@()*[]"))
    title     = ''
    #title
    match = re.compile('<title>(.+?)<', re.IGNORECASE).findall(src)
    title = HTMLParser.HTMLParser().unescape(match[0])
    title = re.sub('\s+-\s*Video\s*-\s*Trilulilu', '', title);
    #f = open( '/storage/.kodi/temp/files.py', 'w' )
    #f.write( 'sxurl = ' + repr(sxurl) + '\n' )
    #f.close()
    choices = []
    stream_url = ""

    if YDStreamExtractor.mightHaveVideo(url, resolve_redirects=True):
        vid = YDStreamExtractor.getVideoInfo(url, quality=1, resolve_redirects=True)  #quality is 0=SD, 1=720p, 2=1080p and is a maximum
        
        if vid:
            if vid.hasMultipleStreams():
                for s in vid.streams():
                    title = s['title']
                    choices.append(title)
                #index = some_function_asking_the_user_to_choose(choices)
                vid.selectStream(0) #You can also pass in the the dict for the chosen stream
    
            stream_url = vid.streamURL()                         #This is what Kodi (XBMC) will play        
            listitem = xbmcgui.ListItem(path=stream_url)
            listitem.setInfo('video', {'Title': title})
            #xbmcplugin.setResolvedUrl(1, True, listitem)
            xbmc.Player().play(item=stream_url, listitem=listitem)
        else:
            return False

    
def get_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    try:
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        return link
    except:
        return False
    
def get_search_url(keyword, offset=None):
    url = 'http://cauta.trilulilu.ro/video/' + urllib.quote_plus(keyword)
    
    if offset != None:
        url += "?offset=" + offset
    
    return url
  
def get_search_video_url(gen, offset=None):
    url = 'http://www.trilulilu.ro/' + gen + '?mimetype=video&header=1'
    if offset != None:
        url += "&amp;offset=" + offset
    
    return url

def get_search(url):
    
    params = {}
    req = urllib2.Request(url, urllib.urlencode(params))
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    req.add_header('Content-type', 'application/x-www-form-urlencoded')
    try:
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        return link
    except:
        return False

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
                                
    return param

def sxaddLink(name, url, iconimage, movie_name, mode=4):
    ok = True
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name)
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": movie_name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz)
    return ok

def addLink(name, url, iconimage, movie_name):
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": movie_name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=liz)
    return ok

def addNext(name, page, mode, iconimage):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(page) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name)
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    #f = open( '/storage/.kodi/temp/files.py', 'w' )
    #f.write( 'sxurl = ' + repr(sys.argv) + '\n' )
    #f.close()
    return ok

def addDir(name, url, mode, iconimage):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok
        
              
params = get_params()
url = None
name = None
mode = None

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass

#print "Mode: "+str(mode)
#print "URL: "+str(url)
#print "Name: "+str(name)

if mode == None or url == None or len(url) < 1:
    ROOT()
        
elif mode == 1:
    CAUTA_VIDEO(url, 'Haioase')
        
elif mode == 2:
    CAUTA_LIST(url)
        
elif mode == 3:
    CAUTA(url)
        
elif mode == 5:
    CAUTA_VIDEO_LIST(url)
        
elif mode == 6:
    CAUTA_VIDEO(url, 'Fail')
        
elif mode == 7:
    CAUTA_VIDEO(url, 'Wow')
        
elif mode == 8:
    CAUTA_VIDEO(url, 'Reclame')

elif mode == 31:
    CAUTA(url, " dublat")

elif mode == 4:
    VIDEO(url, name)

elif mode == 9:
        SXVIDEO_EPISOD_PLAY(url)

elif mode == 10:
        SXVIDEO_GENERIC_PLAY(url)



xbmcplugin.endOfDirectory(int(sys.argv[1]))
